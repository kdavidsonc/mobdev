package com.example.mobdev.homework02_group16;
/**Assignment #: Homework Assignment 2
 * File Name: Homework02_Group16
 * Full name:Khendra Davidson-Carryl
 *  *        Gabriella Gende-Casanova
 * */
import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

public class SelectAvatar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_avatar);
        setTitle("Avatar");

        /*Views for this activity*/
        ImageView f1 = findViewById(R.id.imagef1);
        ImageView f2 = findViewById(R.id.imagef2);
        ImageView f3 = findViewById(R.id.imagef3);
        ImageView m1 = findViewById(R.id.imagem1);
        ImageView m2 = findViewById(R.id.imagem2);
        ImageView m3 = findViewById(R.id.imagem3);

        /*Calls a method that sends the select method to the Main Activity*/
        sendImage(f1);
        sendImage(f2);
        sendImage(f3);
        sendImage(m1);
        sendImage(m2);
        sendImage(m3);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void sendImage(final ImageView image) {
        image.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Intent imageIntent = new Intent(SelectAvatar.this, MainActivity.class);
                imageIntent.putExtra(MainActivity.IMAGE_KEY, v.getId()); //puts content in the result
                setResult(RESULT_OK,imageIntent);
                finish(); //closes Activity
                return false;
            }
        });
    }
}
