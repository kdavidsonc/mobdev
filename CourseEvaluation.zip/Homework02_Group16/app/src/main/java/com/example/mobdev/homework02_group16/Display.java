package com.example.mobdev.homework02_group16;
/**Assignment #: Homework Assignment 2
 * File Name: Homework02_Group16
 * Full name:Khendra Davidson-Carryl
 *  *        Gabriella Gende-Casanova
 * */

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class Display extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        setTitle("Display");

        ImageView image = findViewById(R.id.imageDefault);
        TextView name = findViewById(R.id.textNickname);
        TextView classLevel = findViewById(R.id.textLevel);
        RatingBar course = findViewById(R.id.ratingBarCourse);
        RatingBar deadline = findViewById(R.id.ratingBarDeadline);
        RatingBar assignment = findViewById(R.id.ratingBarAssignment);

        Evaluation e = getIntent().getExtras().getParcelable(MainActivity.PARCEL_KEY);
        String radioText = e.get_class();
        int source = e.getAvatar();
        image.setImageResource(source);
        name.setText(e.getNickName());
        classLevel.setText(radioText + " Student");
        setRating(course, e.getRating1());
        setRating(deadline, e.getRating2());
        setRating(assignment, e.getRating3());

    }

    private void setRating(RatingBar ratingBar, int number) {
        ratingBar.setEnabled(false);
        ratingBar.setRating(number/20);
    }
}
