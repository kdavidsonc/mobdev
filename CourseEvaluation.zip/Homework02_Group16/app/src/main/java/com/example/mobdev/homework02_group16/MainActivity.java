package com.example.mobdev.homework02_group16;
/**Assignment #: Homework Assignment 2
 * File Name: Homework02_Group16
 * Full name:Khendra Davidson-Carryl
 *  *        Gabriella Gende-Casanova
 * */
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
    public static int REQCODE_IMAGE = 1;
    public static String IMAGE_KEY = "Image";
    public static String PARCEL_KEY = "Parcel";

    /*Get the result requested by this Activity*/
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ImageView avatar = findViewById(R.id.imageNoImage);
        if(requestCode == REQCODE_IMAGE){
            if(resultCode == RESULT_OK){
                int image = data.getExtras().getInt(IMAGE_KEY);
                switch (image){
                    case R.id.imagef1:
                        avatar.setTag(R.drawable.avatar_f_1);
                        avatar.setImageResource(R.drawable.avatar_f_1);
                        break;
                    case R.id.imagef2:
                        avatar.setTag(R.drawable.avatar_f_2);
                        avatar.setImageResource(R.drawable.avatar_f_2);
                        break;
                    case R.id.imagef3:
                        avatar.setTag(R.drawable.avatar_f_3);
                        avatar.setImageResource(R.drawable.avatar_f_3);
                        break;
                    case R.id.imagem1:
                        avatar.setTag(R.drawable.avatar_m_1);
                        avatar.setImageResource(R.drawable.avatar_m_1);
                        break;
                    case R.id.imagem2:
                        avatar.setTag(R.drawable.avatar_m_2);
                        avatar.setImageResource(R.drawable.avatar_m_2);
                        break;
                    case R.id.imagem3:
                        avatar.setTag(R.drawable.avatar_m_3);
                        avatar.setImageResource(R.drawable.avatar_m_3);
                        break;
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Main Activity");

        final SeekBar courseBar = findViewById(R.id.seekBarCourse);
        final SeekBar deadlineBar = findViewById(R.id.seekBarDeadline);
        final SeekBar assignmentBar = findViewById(R.id.seekBarAssignment);
        final TextView status1 = findViewById(R.id.textViewStatus1);
        final TextView status2 = findViewById(R.id.textViewStatus2);
        final TextView status3 = findViewById(R.id.textViewStatus3);
        final Button submit = findViewById(R.id.buttonSubmit);
        final EditText name = findViewById(R.id.editTextName);
        final ImageView avatar = findViewById(R.id.imageNoImage);
        final RadioGroup _class = findViewById(R.id.radioGroupClass);

        /*Listen to when the user wants to change their avatar.
        Goes to the Avatar Activity, then returns the choice*/
        avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent getImage = new Intent(MainActivity.this, SelectAvatar.class);
                startActivityForResult(getImage, REQCODE_IMAGE);
            }
        });

        _class.check(R.id.radioButtonLevel1);

        /*Calls the progress listener*/
        listener(courseBar, status1);
        listener(deadlineBar, status2);
        listener(assignmentBar, status3);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton radioButton = findViewById(_class.getCheckedRadioButtonId());
                radioButton.getText();

                //verify that the user entered valid information
                if (!String.valueOf(name.getText()).isEmpty()) {
                    Evaluation e = new Evaluation();

                    e.setNickName(String.valueOf(name.getText()));
                    e.set_class(String.valueOf(radioButton.getText()));
                    e.setAvatar((Integer) avatar.getTag());
                    e.setRating1(courseBar.getProgress());
                    e.setRating2(deadlineBar.getProgress());
                    e.setRating3(assignmentBar.getProgress());
                    /*Explicit Intent, check corresponding manifest*/
                    Intent submitForm = new Intent("com.example.mobdev.homework02_group16.intent.action.VIEW");
                    submitForm.putExtra(PARCEL_KEY,e);
                    startActivity(submitForm);
                } else {
                    Toast.makeText(getApplicationContext(), "Please enter a valid name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    private void listener(SeekBar seekBar, final TextView textview) {
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            /*Keeps track of the Seeker position*/
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(progress <= 20)
                {
                    seekBar.setProgress(0);
                    textview.setText("Strongly Disagree");
                }
                else if(progress > 20 && progress <= 40)
                {
                    seekBar.setProgress(40);
                    textview.setText("Disagree");
                }
                else if(progress > 40 && progress <= 60)
                {
                    seekBar.setProgress(60);
                    textview.setText("Neutral");
                }
                else if(progress > 60 && progress <= 80)
                {
                    seekBar.setProgress(80);
                    textview.setText("Agree");
                }
                else
                {
                    seekBar.setProgress(100);
                    textview.setText("Strongly Agree");
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }
}
