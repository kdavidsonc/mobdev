/**Assignment #02.
 * File Name: InClass02
 * Full name: Khendra Davidson-Carryl
 *          Gabriella Gende-Casanova
 * **/
package com.example.kdavi.areacalculator;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.String;

import static android.view.View.FOCUSABLE;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        /**Accessing Buttons**/
        Button clearButton = findViewById(R.id.buttonClear);
        Button calculateButton = findViewById(R.id.buttonCalculate);


        final String[] s = getResources().getStringArray(R.array.shapes);

        /**Accessing Shapes**/
        final ImageView circle = findViewById(R.id.imageCircle);
        final ImageView square = findViewById(R.id.imageSquare);
        final ImageView triangle = findViewById(R.id.imageTriangle);

        /**Accessing text values. Need to be final, used within inner classes**/
        final EditText area = findViewById(R.id.editArea);
        final EditText length1 = findViewById(R.id.editLength1);
        final EditText length2 = findViewById(R.id.editLength2);
        final TextView select = findViewById(R.id.textViewSelect);
        final TextView tv_length2 = findViewById(R.id.textViewLength2);


        //for (String word : s) {
        Log.d("Things", s[0]);
        //}

        /**Listens for movement**/
        triangle.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View t, MotionEvent event) {
                select.setText(s[0]);
                length2.setVisibility(View.VISIBLE);
                tv_length2.setVisibility(View.VISIBLE);
                return false;
            }
        });
        square.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View q, MotionEvent event) {
                select.setText(s[1]);
                length2.setVisibility(View.INVISIBLE);
                tv_length2.setVisibility(View.INVISIBLE);
                return false;
            }
        });

        circle.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View c, MotionEvent event) {
                select.setText(s[2]);
                length2.setVisibility(View.INVISIBLE);
                tv_length2.setVisibility(View.INVISIBLE);
                return false;
            }
        });

        //Log.i("Things", String.valueOf(View.));

        /**Listens for Click events**/
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Things", String.valueOf(length2.getEditableText()));
                Log.i("Things", String.valueOf(select.getText()));
                //String viewToTeext1 = length1.getText().toString();
                double textToDouble1 = 1;
                double textToDouble2 = 1;
                try {
                    textToDouble1 = Double.parseDouble(length1.getText().toString());
                    textToDouble2 = Double.parseDouble(length2.getText().toString());

                } catch (NumberFormatException e) {
                    if(length1.getText().toString().equals("")){
                        textToDouble1 = 1;
                    }
                    if(length2.getText().toString().equals("")){
                        textToDouble2 = 1;
                    }
                }

                Log.i("Things", String.valueOf(select.getText()));
                switch (String.valueOf(select.getText())) {
                    case "Triangle":
                        area.setText(String.valueOf(0.5 * textToDouble1 * textToDouble2));
                        break;
                    case "Square":
                        area.setText(String.valueOf(textToDouble1 * textToDouble1));
                        break;
                    case "Circle":
                        area.setText(String.valueOf(textToDouble1 * textToDouble1 * 3.1416));
                        break;
                    default:
                        area.setText("");
                }
            }
        });

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                length1.setText("");
                length2.setText("");
                area.setText("");
                select.setText("Select a shape");
                length2.setVisibility(View.VISIBLE);
                tv_length2.setVisibility(View.VISIBLE);
            }
        });

    }

}



