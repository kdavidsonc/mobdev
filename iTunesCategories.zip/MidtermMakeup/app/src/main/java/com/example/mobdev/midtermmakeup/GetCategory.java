package com.example.mobdev.midtermmakeup;
/*********************
 Full name: Khendra Davidson
 **************************/
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class GetCategory extends AsyncTask<String, String, ArrayList<MediaItem>> {
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected ArrayList<MediaItem> doInBackground(String... strings) {
        StringBuilder stringBuilder = new StringBuilder();
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        String response = null;
        ArrayList<MediaItem> media = new ArrayList<>();
        try {
            URL url = new URL(strings[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();

            int code = connection.getResponseCode();
            if (code == HttpURLConnection.HTTP_OK) {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = "";
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                response = stringBuilder.toString();
                ParseJson json = new ParseJson();
                media = json.parseJson(response);
            }
            else
            {
                Log.d("Test", "The code is "+code);
            }

        }catch(MalformedURLException m){
            Log.d("Test", "Invalid URL");
        }catch (IOException i){
            Log.d("Test", "Bad Connection");
        }finally {
            connection.disconnect();
        }

        return media;
    }
    @Override
    protected void onPostExecute(ArrayList s) {
        super.onPostExecute(s);

    }
}
