package com.example.mobdev.midtermmakeup;
/*********************
 Full name: Khendra Davidson
 **************************/
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ParseJson {
    static private ArrayList<MediaItem> mediaList = new ArrayList<>();

    static public ArrayList<MediaItem> parseJson(String jsonFile) {
        try {

            JSONObject root = new JSONObject(jsonFile);
           // Log.d("Test", "ParseJson root: \t" + root + "\n");
            JSONObject parentObj = root.getJSONObject("feed");
            JSONArray parentArray = parentObj.getJSONArray("results");
            ArrayList<MediaItem> list = new ArrayList<>();
            //Log.d("Test", "Parent JSON is: \n" + parentObj + "\n");

            for (int i = 0; i < parentArray.length()-1; i++) {

                MediaItem media = new MediaItem();
                media.setArtistName(parentArray.getJSONObject(i).getString("artistName"));
                media.setArtworkURL100(parentArray.getJSONObject(i).getString("artworkUrl100"));
                media.setKind(parentArray.getJSONObject(i).getString("kind"));
                media.setName(parentArray.getJSONObject(i).getString("name"));
                media.setReleaseDate(parentArray.getJSONObject(i).getString("releaseDate"));

               // Log.d("Test", "ParseJson before: " +media.toString());
                list.add(media);
            }
            mediaList = list;
        } catch (
                JSONException j) {
            Log.d("Test", "Unable to parse JSON file");
        }


        return mediaList;
    }
}
