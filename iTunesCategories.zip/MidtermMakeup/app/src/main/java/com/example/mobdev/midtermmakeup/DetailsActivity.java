package com.example.mobdev.midtermmakeup;
/*********************
 Full name: Khendra Davidson
 **************************/
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        //Change the title and text field to the category selected
        MediaItem item = (MediaItem) getIntent().getExtras().getSerializable("View");

        ImageView image = findViewById(R.id.imageView);
        TextView name =  findViewById(R.id.textViewName);
        TextView releaseDate =  findViewById(R.id.textViewReleaseDate);

        name.setText(item.getName());
        setTitle(item.getArtistName());
        releaseDate.setText(item.getReleaseDate());
        Picasso.get().load(item.getArtworkURL100()).into(image);

    }
}
