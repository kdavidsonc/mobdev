package com.example.mobdev.midtermmakeup;
/*********************
 c. Full name: Khendra Davidson
 **************************/
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

public class CategoriesActivity extends AppCompatActivity {
    static String RESULT = "Result";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);
        setTitle("Categories");


        final String[] media = new String[]{"Top Songs", "Top Albums", "Top Grossing Apps", "Top TV Episodes", "Top Books"};
        ListView list = findViewById(R.id.list);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, android.R.id.text1, media);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Return the category to Main Activity
                Intent sendCategory = new Intent();
                sendCategory.putExtra(RESULT, position);

                setResult(RESULT_OK, sendCategory);
                finish();
            }
        });




    }
}
