package com.example.mobdev.midtermmakeup;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class CategoryAdapter extends ArrayAdapter {
    ArrayList<MediaItem> itemsList = new ArrayList<>();
    public CategoryAdapter(@NonNull Context context, int resource, @NonNull ArrayList objects) {
        super(context, resource, objects);

             itemsList = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listView = convertView;
        if(listView == null)
            listView = LayoutInflater.from(this.getContext()).inflate(R.layout.media_list_item,parent,false);
        final MediaItem item = itemsList.get(position);

        ImageView image = listView.findViewById(R.id.imageView);
        TextView name =  listView.findViewById(R.id.textViewName);
        TextView artist = listView.findViewById(R.id.textViewArtist);
        TextView releaseDate =  listView.findViewById(R.id.textViewReleaseDate);
        TextView kind = listView.findViewById(R.id.textViewKind);

        name.setText(item.getName());
        artist.setText(item.getArtistName());
        releaseDate.setText(item.getReleaseDate());
        kind.setText(item.getKind());
        Picasso.get().load(item.getArtworkURL100()).into(image);
        return listView;
    }
}
