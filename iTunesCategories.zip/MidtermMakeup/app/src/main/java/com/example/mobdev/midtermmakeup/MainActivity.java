package com.example.mobdev.midtermmakeup;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

/*********************
 Full name: Khendra Davidson
 **************************/
public class MainActivity extends AppCompatActivity {
    static public int CATEGORY_ITEM = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button selectCategoryButton = findViewById(R.id.buttonSelectCategory);;
        //Make sure no category is selected when apps start

        /**OnClick go to the Select Category Activity
         * Start Activity for Result
         */
        selectCategoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent getCategory = new Intent(MainActivity.this, CategoriesActivity.class);
                startActivityForResult(getCategory, CATEGORY_ITEM);
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {


        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
               // Log.d("test", "OK Results");
                GetCategory getc = new GetCategory();

                if (!isConnected()) {
                    Toast.makeText(MainActivity.this, "Please Connect to Internet", Toast.LENGTH_SHORT);
                } else {
                    int selection = Integer.parseInt(String.valueOf(data.getExtras().getInt(CategoriesActivity.RESULT)));
                    switch (selection) {
                        //"Top Songs", "Top Albums", "Top Grossing Apps", "Top TV Episodes", "Top Books"
                        case 0:
                            setTitle("Top Songs");
                            getc.execute("https://rss.itunes.apple.com/api/v1/us/itunes-music/top-songs/all/20/explicit.json");
                            break;
                        case 1:
                            setTitle("Top Albums");
                            getc.execute("https://rss.itunes.apple.com/api/v1/us/itunes-music/top-albums/all/20/explicit.json");
                            break;
                        case 2:
                            setTitle("Top Grossing Apps");
                            getc.execute("https://rss.itunes.apple.com/api/v1/us/ios-apps/top-grossing/all/20/explicit.json");
                            break;
                        case 3:
                            setTitle("Top TV Episodes");
                            getc.execute("https://rss.itunes.apple.com/api/v1/us/tv-shows/top-tv-episodes/all/20/explicit.json");
                            Log.d("test", String.valueOf(selection));
                            break;
                        case 4:
                            setTitle("Top Books");
                            getc.execute("https://rss.itunes.apple.com/api/v1/us/books/top-paid/all/20/explicit.json");
                            break;
                        default:
                            Log.d("test", "something went wrong");
                            Log.d("test", String.valueOf(resultCode));
                    }

                    try{
                        final ArrayList<MediaItem> medialist = getc.get();
                        ListView categoryList = findViewById(R.id.listView);
                       CategoryAdapter adapter = new CategoryAdapter(MainActivity.this, R.layout.media_list_item,medialist);
                         categoryList.setAdapter(adapter);
                    categoryList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                            intent.putExtra("View", medialist.get(position));
                            startActivity(intent);
                        }
                    });

                }catch (ExecutionException e){
                        e.printStackTrace();
                    }catch (InterruptedException i){
                        i.printStackTrace();
                    }
                }
            } else {
                Log.d("test", "something went wrong");
                Log.d("test", String.valueOf(resultCode));
            }
        }
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(this.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;

    }

}
