package com.example.mobdev.midtermmakeup;
/*********************
 Full name: Khendra Davidson
 **************************/
import java.io.Serializable;

public class MediaItem implements Serializable {
    //Create media Item here

    public MediaItem() {
    }

    private String artistName;
    private String name;
    private String releaseDate;
    private String kind;
    private String artworkURL100;

    public String getArtistName() {
        return artistName;
    }

    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getArtworkURL100() {
        return artworkURL100;
    }

    public void setArtworkURL100(String artworkURL100) {
        this.artworkURL100 = artworkURL100;
    }

    @Override
    public String toString() {
        return "MediaItem{" +
                "artistName='" + artistName + '\'' +
                ", name='" + name + '\'' +
                ", releaseDate='" + releaseDate + '\'' +
                ", kind='" + kind + '\'' +
                ", artworkURL100='" + artworkURL100 + '\'' +
                '}';
    }
}
