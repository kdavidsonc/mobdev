package com.example.mobdev.inclass11_group8;
/**
 * Full name: Khendra Davidson
 * **/

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static com.example.mobdev.inclass11_group8.R.*;

public class MainActivity extends AppCompatActivity {
    public String TAG ="test";
    public Date date = new Date();
    private ArrayList<TodoItem> items = new ArrayList<>();
    private final String now = date.toString();
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.sss");
    DBQuery dbq = new DBQuery(this);

  @Override
    protected void onStart() {
        super.onStart();
        if((items = dbq.get()) != null) {
            updateList(items);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);
        //Log.d(TAG, "onCreate: menu " + R.menu.show_menu);
        Button bAdd = findViewById(id.buttonAdd);
        bAdd.setOnClickListener(new View.OnClickListener() {
            EditText etTitle = findViewById(id.editTextTitle);
            Spinner sPriority = findViewById(id.spinnerPriorty);

            @Override
            public void onClick(View v) {
                date.setTime(System.currentTimeMillis());
                TodoItem item = new TodoItem(
                        String.valueOf(etTitle.getText()),
                        String.valueOf(sPriority.getSelectedItem()),
                        format.format(date), 0);
                item.setId(dbq.insert(item));
                item.toString();
                items = dbq.get();
                updateList(items);
                etTitle.setText(null);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.show_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case id.all:
                items = dbq.get();
                updateList(items);
                return true;
            case id.complete:
                items = dbq.get(1);
                updateList(items);
                return true;
            case id.pending:
                items = dbq.get(0);
                updateList(items);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateList(ArrayList<TodoItem> array){
        ListView list = findViewById(R.id.list_dynamic);
        MyAdapter adapter = new MyAdapter(MainActivity.this, R.layout.todo_list, array);
        list.setAdapter(adapter);
    }
}
