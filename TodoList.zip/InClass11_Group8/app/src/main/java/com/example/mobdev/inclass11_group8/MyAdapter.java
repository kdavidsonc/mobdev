package com.example.mobdev.inclass11_group8;
/**
 * Full name: Khendra Davidson
 * **/
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.util.ArrayList;

public class MyAdapter extends ArrayAdapter {
    private ArrayList<TodoItem> todoItemList = new ArrayList<>();
    private String TAG = "test";
    public MyAdapter(@NonNull Context context, int resource, @NonNull ArrayList objects) {
        super(context, resource, objects);
        todoItemList = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View listView = convertView;
        if(listView == null)
            listView = LayoutInflater.from(this.getContext()).inflate(R.layout.todo_list,parent,false);
        final TodoItem todoItem = todoItemList.get(position);

        TextView title = listView.findViewById(R.id.textViewTitle);
        TextView priority = listView.findViewById(R.id.textViewPriorty);
        TextView time = listView.findViewById(R.id.textViewTime);
        final CheckBox status = listView.findViewById(R.id.checkBox);

        if (todoItem.getStatus() == 1) {
            status.setChecked(true);
        }else{
            status.setChecked(false);
        }


        listView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final DBQuery dbq = new DBQuery(getContext());

                final AlertDialog.Builder alert = new AlertDialog.Builder(getContext());
                alert.setTitle("Delete Item")
                        .setMessage("Delete Item: " + todoItem.getTitle())
                        .setCancelable(true)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dbq.delete(todoItem.getId());
                                remove(todoItem);
                                AlertDialog.Builder box = new AlertDialog.Builder(getContext());
                                box.setTitle(String.valueOf(todoItem.getId()))
                                        .setMessage("Deleted");
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                                            }
                        });

                AlertDialog showAlert = alert.create();
                showAlert.show();
                return false;
            }
        });

        status.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            final DBQuery dbq = new DBQuery(getContext());

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    todoItem.setStatus(1);
                    status.setChecked(true);
                    Toast.makeText(getContext(), "Completed", Toast.LENGTH_LONG);
                }
                if(!isChecked) {
                    todoItem.setStatus(0);
                    status.setChecked(false);
                    Toast.makeText(getContext(), "Removed", Toast.LENGTH_LONG);
                }
                dbq.update(todoItem.getId(), todoItem.getStatus());
            }
        });

        title.setText(todoItem.getTitle());
        priority.setText(todoItem.getPriority());
        time.setText(todoItem.getDate());

        return listView;
    }
}

