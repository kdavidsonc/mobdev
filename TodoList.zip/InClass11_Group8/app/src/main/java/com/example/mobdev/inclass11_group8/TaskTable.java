package com.example.mobdev.inclass11_group8;
/**
 * Full name: Khendra Davidson
 * **/
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class TaskTable {
/**Creates database columns**/
    public static final String TABLE_NAME = "task";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_PRIORITY = "priority";
    public static  String TAG = "test";

    /**Creates database**/
    static public void onCreate(SQLiteDatabase db) {
        StringBuilder sb = new StringBuilder();
        sb.append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COLUMN_ID)
                .append(" INTEGER primary key autoincrement,")
                .append(COLUMN_TITLE)
                .append(" TEXT not null,")
                .append(COLUMN_PRIORITY)
                .append(" TEXT not null,")
                .append(COLUMN_DATE)
                .append(" DATETIME not null,")
                .append(COLUMN_STATUS)
                .append(" BOOLEAN not null)" )
        ;

        try
        {
            db.execSQL(sb.toString());

        }
        catch (SQLException e){
            e.printStackTrace();

        }
    }
    static public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        Log.d(TAG, "onUpgrade: ");
        TaskTable.onCreate(db);
    }
}
