package com.example.mobdev.inclass11_group8;
/**
 * Full name: Khendra Davidson
 * **/
public class TodoItem {

    private long id;
    private String title;
    private String priority;
    private String date;
    private int status;



    public TodoItem(){

    }

    public TodoItem(String title, String priority, String date, int status) {
        setTitle(title);
        setPriorty(priority);
        setDate(date);
        setStatus(status);
    }

    public TodoItem(long id, String title, String priority, String date, int status) {
        setId(id);
        setTitle(title);
        setPriorty(priority);
        setDate(date);
        setStatus(status);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriorty(String priority) {
        this.priority = priority;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "TodoItem{" +
                "title:\t" + title +
                ", priority:\t" + priority +
                ", date:\t" + date +
                ", status:\t" + status +
                '}';
    }
}
