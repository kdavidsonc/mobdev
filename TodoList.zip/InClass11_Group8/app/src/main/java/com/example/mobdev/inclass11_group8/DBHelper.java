package com.example.mobdev.inclass11_group8;
/**
 * Full name: Khendra Davidson
 * **/
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper{
    static final int DB_VERSION = 1;
    static final String DB_NAME = "Task.db";
    private String TAG = "test";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        TaskTable.onCreate(db);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        TaskTable.onUpgrade(db,oldVersion,newVersion);
        Log.d(TAG, "onUpgrade: ");
    }

}
