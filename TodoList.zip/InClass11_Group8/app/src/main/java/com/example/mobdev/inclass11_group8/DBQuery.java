package com.example.mobdev.inclass11_group8;
/**
 * Full name: Khendra Davidson
 * **/
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;

public class DBQuery {
    public String TAG = "test";
    private DBHelper helper;
    //private ArrayList<TodoItem> items  = new ArrayList<>();


    public DBQuery(Context context){
        helper = new DBHelper(context);
        //Log.d(TAG, "DBQuery: constructor");
    }

    public long insert(TodoItem item) {     // get writable database as we want to write data
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(TaskTable.COLUMN_TITLE, item.getTitle());
        values.put(TaskTable.COLUMN_PRIORITY, item.getPriority());
        values.put(TaskTable.COLUMN_DATE, item.getDate());
        values.put(TaskTable.COLUMN_STATUS, item.getStatus());

        // insert row
        item.setId(db.insert(TaskTable.TABLE_NAME, null, values));

        // close db connection
        db.close();

        // return newly inserted row id
        return item.getId();
    }

    public ArrayList<TodoItem> get(long id) {
        // get readable database as we are not inserting anything
        ArrayList<TodoItem> items  = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        TodoItem item = new TodoItem();
        String[] columns = {TaskTable.COLUMN_ID,
                TaskTable.COLUMN_TITLE,
                TaskTable.COLUMN_PRIORITY,
                TaskTable.COLUMN_STATUS,
                TaskTable.COLUMN_DATE};
        //place columns in an array
        Cursor cursor = db.query(TaskTable.TABLE_NAME, //table we are searching
                columns, //what should we return
                TaskTable.COLUMN_ID + "=?", //WHERE "id" = '...'
                //values, groupby, filter, sort
                new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null) {
            items = qRetrieve(cursor);
        }
        cursor.close();
        return items;
    }

    public ArrayList<TodoItem> get() {
        // get readable database as we are not inserting anything
        ArrayList<TodoItem> items  = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        String[] columns = {TaskTable.COLUMN_ID,
                TaskTable.COLUMN_TITLE,
                TaskTable.COLUMN_PRIORITY,
                TaskTable.COLUMN_STATUS,
                TaskTable.COLUMN_DATE};

        Log.d(TAG, "get w/out params: ");
        //place columns in an array
        Cursor cursor = db.query(TaskTable.TABLE_NAME, //table we are searching
                columns, //what should we return
                null, //select all
                //values, groupby, filter, sort
                null, null, null, TaskTable.COLUMN_PRIORITY + " DESC", null);

        if (cursor != null) {
            //cursor.moveToFirst();
            items = qRetrieve(cursor);
        }
        cursor.close();
        return items;
    }

    public ArrayList<TodoItem> get(int status) {
        // get readable database as we are not inserting anything
        ArrayList<TodoItem> items  = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        String[] columns = {TaskTable.COLUMN_ID,
                TaskTable.COLUMN_TITLE,
                TaskTable.COLUMN_PRIORITY,
                TaskTable.COLUMN_STATUS,
                TaskTable.COLUMN_DATE};

        Log.d(TAG, "get w/ params status: ");
        //place columns in an array
        Cursor cursor = db.query(TaskTable.TABLE_NAME, //table we are searching
                columns, //what should we return
                TaskTable.COLUMN_STATUS + "=?", //WHERE "id" = '...'
                //values, groupby, filter, sort
                new String[]{String.valueOf(status)}, null, null, null, null);

        if (cursor != null) {
            items = qRetrieve(cursor);
        }
        cursor.close();
        return items;
    }

    public void delete(long id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        int deletedRows = db.delete(TaskTable.TABLE_NAME,
                TaskTable.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void update(long id, int updateValue){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TaskTable.COLUMN_STATUS, updateValue);

        db.update(
                TaskTable.TABLE_NAME, //table to update
                values,
                TaskTable.COLUMN_ID + " LIKE ?", //row to update
                new String[]{String.valueOf(id)});
    }

    private ArrayList<TodoItem> qRetrieve(Cursor c){
        ArrayList<TodoItem> items = new ArrayList<>();
        while (c.moveToNext()) {
            TodoItem item = new TodoItem(
                    c.getInt(c.getColumnIndex(TaskTable.COLUMN_ID)),
                    c.getString(c.getColumnIndex(TaskTable.COLUMN_TITLE)),
                    c.getString(c.getColumnIndex(TaskTable.COLUMN_PRIORITY)),
                    c.getString(c.getColumnIndex(TaskTable.COLUMN_DATE)),
                    c.getInt(c.getColumnIndex(TaskTable.COLUMN_STATUS)));
            items.add(item);
        }
        return items;
    }
}
